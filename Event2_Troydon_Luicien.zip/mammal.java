package adventure;

    public class mammal extends animal
    {
         private int health;
             
         mammal (String n,int p, int s, int h, int d )
         {
             setName(n);
             setPosition(p);
             setSpeed(s);
             setHealth(h);
             setDirection(d);
             
             
         }
         public void setHealth(int h)
         {
             health = h;
         }        
         
         public int getHealth()
         {
            return health;
         }   
         
         public void injure()
         {
             setHealth(getHealth() - 10);
         }
         
         public void recover()
         {
             setHealth(getHealth() + 10);
         }        
         @Override
         public void report()    
         {
            System.out.println(getName());
            System.out.println("Position: " + getPosition());
            System.out.println("Speed: " + getSpeed() );
            System.out.println("Direction: " +  getDirection());
            System.out.println("Health score " + health); 
            System.out.println("-----------------------");
            
         } 
    }  
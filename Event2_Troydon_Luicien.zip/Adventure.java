
package adventure;
/**
 * Program name: Adventure. This program begins an adventure with a bird.
 * Default birds are added to the list, you are then prompted to add birds or deleted birds.
 * The list is sorted alphabetically, if you select a bird not on the list you will be assigned
 * default health to begin with. Health depends on the birds selected.
 * @Version 1.0
 * @author T.Luicien
 * @Date 25/04/2019 
 * @ Environment: Windows 10 Developed under NetBeans IDE
 * 8.0.2 under Java 7 Contact: tluicien@yahoo.co.nz
 */
import java.util.Scanner;
import java.util.*;

public class Adventure {

    /**
     * @param args the command line arguments
     */
    private boolean status; //declares boolean called status
    ArrayList<String> myBirdList = new ArrayList();
    String chosenBird = "";

    public static void main(String[] args) {
        Adventure myAdventure = new Adventure();
        myAdventure.reportModification();
        // myAdventure.searchBird();
        System.out.println("Now select the bird to use");
        Scanner myInput = new Scanner(System.in);
        myAdventure.chosenBird = myInput.nextLine();
        myAdventure.determineHealth();
        myAdventure.setStatus(true);
        myAdventure.startAdventure();
    }

    public boolean getStatus() { //method to return status for commands
        return status;
    }

    public void setStatus(boolean s) { //method to status
        status = s;
    }
    
    //method for adding birds
    public void addBird(ArrayList<String> a, String v) {
        int low, mid, high, entryPoint, i;
        low = 0; //initial low is position 0
        high = a.size(); //initial high is the the size of array list e.g 5 here
        entryPoint = 0; //entry point inititally 0
        boolean found = false;
        while (!found) {
            mid = (high + low) / 2;
            if (high - low == 1) { //if the high point - low point is == 1 finish
                entryPoint = high; //entry point is assigned value
                found = true;
            } else if (v.compareTo(a.get(mid)) < 0) { //negative number, if first called value comes before initial midpoint
                high = mid;
            } else {
                low = mid;// mid is low if the search value is higher
            }
        }
    // now move the values down
        a.add(a.get(a.size() - 1)); //(the size of a) - 1 is determined, then retrieved, then added
        for (i = a.size() - 1; i > entryPoint; i--) { //initial value is the above, while i is greater then entry, we decrement
            a.set(i, a.get(i - 1)); //set to change value of i(value prev), for the value of the prev - 1
        }
        a.set(entryPoint, v); //sets the entry point with the value of v

    }
    
    //check if the char is uppercase method
    static boolean isUpperCase(char ch) { //check if char is upper case
        return ch >= 'A' && ch <= 'Z';
    }
    
    //adding method for new birds
    public void beginAdding() {

        System.out.println("Please enter a bird name to add");
        Scanner inputName = new Scanner(System.in);
        String birdToAdd = inputName.nextLine(); //gets user input
        if (isUpperCase(birdToAdd.charAt(0))) { // check if input is uppercase
            addBird(myBirdList, birdToAdd); //add bird
            System.out.println(birdToAdd + " has been added, continue to modify with 'add' or 'delete' or 'stop'");
            showList();
        } else {
            System.out.println("Sorry your bird must start with an upper case letter, please enter a valid command, select 'add' delete' or 'stop'");
        }
    }
    
    //method to remove birds from the list
    public void deleteBird() {
        showList();
        int a;
        System.out.println("Please enter a bird name to remove");
        Scanner inputName = new Scanner(System.in);
        String unwantedBird = inputName.nextLine();

        for (a = 0; a < myBirdList.size(); a++) {//split list into strings
            String removeBird = myBirdList.get(a); //e.g String peacock

            if ((unwantedBird.equals(removeBird))) {//if bird entered is the same as bird in list, this bird is removed
                System.out.println(myBirdList.get(a) + " is now being deleted, select 'add' delete' or 'stop'");
                myBirdList.remove(a); //delete bird if true
            }
            else{
                System.out.println(unwantedBird + " is not on the list. select 'add' delete' or 'stop'");
                break;
            }
        }
    }

    //Binary Search code retrieved from the below resource
/*    ***************************************************************************************
*    Title: Binary Search a String
*    Author: Samuel, A
*    Date Retrieved : 24/04/2019
*    Availability: https://www.geeksforgeeks.org/
*
****************************************************************************************/
    static int binarySearch(String[] arr, String x) {
        int l = 0, r = arr.length - 1; //length -1 as don't use all
        while (l <= r) {  //iterate for the duration of the array
            int m = l + (r - l) / 2; //m is the middle of the reference

            int res = x.compareTo(arr[m]); //if the string being searched comes before the string in the middle

            // Check if x is present at mid 
            if (res == 0) //if searched string is in middle we found th result
            {
                return m;
            }

            // If x greater, ignore left half 
            if (res > 0) {
                l = m + 1;
            } // If x is smaller, ignore right half 
            else {
                r = m - 1;
            }
        }
        return -1;
    }
    
    //gives user the option to add or remove birds or move on
    public void reportModification() {
        myBirdList.add("Golden Phesant");
        myBirdList.add("Kingfisher");
        myBirdList.add("Green Jay");
        myBirdList.add("Peacock");
        myBirdList.add("Vulture");
        myBirdList.add("Pheonix Falcon");
        Collections.sort(myBirdList);//sort bird into alphabetical order
        System.out.println("\nHere is the bird list");
        showList();

        //begin add or remove bird to the list
        System.out.println("Choose 'add' to add another bird or 'delete' to remove a bird from the list, 'stop' to finish");
        Scanner myInput = new Scanner(System.in);
        String myValue = "";
        do { //continue doing the following input until s is typed
            myValue = myInput.nextLine();
            if ("add".equals(myValue)) { //if user selects add then adds bird
                beginAdding();
            } else if ("delete".equals(myValue)) {
                deleteBird();
            } else if ("stop".equals(myValue)) {
                System.out.println("You have finished changing birds list");
            } else {
                System.out.println("Sorry that is not valid! please enter a valid command, select 'add' delete' or 'stop'");
            }
        } while (!myValue.contains("stop")); //when value contains Finish user input request ends
        System.out.println("\n Here is the bird list after modification");
        showList();
    }
    
    //method to print list of birds
    public void showList() {
        int i;
        for (i = 0; i < myBirdList.size(); i++) {
            System.out.print(myBirdList.get(i) + ", ");
        }
        System.out.println("\n");
    }
    
    public String chooseBird() {
        
        //default bird is what is performed by user input
        String useBird = chosenBird;

        String[] tempArr = new String[myBirdList.size()];
        tempArr = myBirdList.toArray(tempArr);

        //begin search for user input using binary string search with user input
        int result = binarySearch(tempArr, chosenBird);//search is converted number as string uses number to get binary number result

        while (result != -1) {
            if (result == -1) {
                System.out.println("Search is not present, you will given default health 100");
            } else {
                useBird = myBirdList.get(result);
            }
            result = -1; //set result to -1 once we have added to end while loop
        }
        return useBird;
    }
    
     //health to be determined depending on selected bird
    public int determineHealth() {
        int selectedHealth;
        if (chooseBird() == "Golden Phesant") {
            return selectedHealth = 140;
        } else if (chooseBird() == "Kingfisher") {
            return selectedHealth = 125;
        } else if (chooseBird() == "Green Jay") {
            return selectedHealth = 135;
        } else if (chooseBird() == "Peacock") {
            return selectedHealth = 140;
        } else if (chooseBird() == "Pheonix Falcon") {
            return selectedHealth = 180;
        } else if (chooseBird() == "Vulture") {
            return selectedHealth = 165;
        } else {
            return selectedHealth = 100;//default health for non listed birds
        }
    }
//=================================ADVENTURE BEGINS================================================//

    public void startAdventure() {
        mammal myMammal = new mammal("Dog", 0, 0, 100, 1);//instantiating mammal with initial values
        Bird myBird = new Bird(chooseBird(), false, false, 0, 0, determineHealth(), 1, 0);//bird starts off 

        while (getStatus()) {
            System.out.println("\nUse the commands below to command the bird");
            System.out.println("m - move");
            System.out.println("a - accelerate");
            System.out.println("b - brake");
            System.out.println("feed - brake open nuts");
            System.out.println("h - home");
            System.out.println("open - open wings to enable flight");
            System.out.println("close - close wings to close flight");
            System.out.println("nest - choose to go to nest");
            System.out.println("sleep - choose close eyes");
            System.out.println("wake - choose to open eyes");
            System.out.println("climb - climb to fly");
            System.out.println("t - turn around");
            System.out.println("q - quit");
            System.out.println("\nEnter a function, 'q' to quit");
            Scanner myInput = new Scanner(System.in);
            String mykey;
            mykey = myInput.next();
            switch (mykey) {
                case "a":
                    myBird.accelerate();
                    break;
                case "b":
                    myBird.brake();
                    break;
                case "feed":
                    myBird.breakOpen(); //eats food and looses default amount of health and speed but gains random health
                   System.out.println(myBird.getName() + " Starts biting at the nut... Crack!.. Ouch that hurt!.."
                           + " wait?.. looks like there is some food in" + myBird.getName() + " eats it and gained some health");
                    break;
                case "h":
                    myBird.home();
                    System.out.println(myBird.getName() + " has returned to " + myBird.getPosition());
                    break;
                case "t":
                    myBird.turn();
                    break;
                case "open":
                    myBird.setWings(true);
                    System.out.println("Wings are opened");
                    break;
                case "close":
                    myBird.setWings(false);
                    System.out.println("Wings are closed");
                    break;
                case "climb":
                    myBird.climb();//increase altitude
                    break;
                case "nest":
                    myBird.atNest();//choose if you want to recover, recover faster with eyes closed
                    break;
                case "sleep":
                    myBird.setEyes(true);
                    System.out.println("Your eyes are now closed");
                    break;
                case "wake":
                    myBird.setEyes(false);
                    System.out.println("your eyes are now opened");
                    break;
                case "m":
                case "M":
                    break;
                case "q":
                    setStatus(false);
                    break;
                default:
                    System.out.println("I didn't recognise that");
            }
            myBird.move();
            myBird.report();
        }
    }
}


package adventure;

  public class animal 
    {
        private String name;
        private int position;
        private int speed;
        private int direction;
        
        public void animal()
        {
            
        }       
        public String getName() 
        {
            return name;
        
        }
        public int getPosition()
        {
            return position;
        }
        public int getSpeed()
        {
            return speed;
        }
        public int getDirection()
        {
            return direction;
        }
        
        public void setName(String n )
        {
            name = n;
        }
        
        public void setPosition (int p)
        {
            position = p;
        }
        public void setSpeed (int s)
        {
            speed = s;
        }
        public void setDirection (int d)
        {
            direction = d;
        }
        public void home()
        {
            setPosition(0);
        }
        
        public void move()
        {
          setPosition(getPosition() + getSpeed()*getDirection())  ;    
        }
        
        public void report()
        {
            System.out.println(getName() + "is bird being used");
            System.out.println("Position: " + getPosition());
            System.out.println("Speed: " + getSpeed() );
            System.out.println("Direction: " +  getDirection());
            System.out.println("-----------------------");
        }
        
        public void accelerate()
        {
            setSpeed( 10 + getSpeed());
        }
        public void brake()
        {
                
            setSpeed( getSpeed() - 10);
            
        }
        public void turn()
        {
            setDirection(getDirection()* -1);
        }
        public void stop()
        {
            setSpeed(0);
        }
    }
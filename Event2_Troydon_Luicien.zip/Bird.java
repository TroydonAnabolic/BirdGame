package adventure;

public class Bird extends animal {

    //fields
    private int health;
    private int altitude; //in meters
    private boolean wingSettings;
    private boolean nest;

    Bird(String n, boolean w, boolean e, int p, int s, int h, int d, int a) {
        setName(n);
        setPosition(p);
        setSpeed(s);
        setHealth(h);
        setDirection(d);
        setWings(w);
        setEyes(e);
        setAltitude(a);
    }

    //getters
    public int getHealth() {
        return health;
    }

    public boolean getEyes() { //method to return status for commands
        return nest;
    }

    public int getAltitude() {
        return altitude;
    }

    public boolean getWings() {
        return wingSettings;
    }

    //setters
    public void setWings(boolean w) {
        wingSettings = w;
    }

    public void setEyes(boolean e) { //method to status
        nest = e;
    }

    public void setHealth(int h) {
        health = h;
    }

    public void setAltitude(int a) {
        altitude = a;
    }

    //write to console
    @Override
    public void report() {
        System.out.println("\n" + getName());
        System.out.println("Position: " + getPosition());
        System.out.println("Speed: " + getSpeed());
        System.out.println("Direction: " + getDirection());
        System.out.println("Health score " + health);
        System.out.println("Altitude " + getAltitude());
        System.out.println("-----------------------");

    }

    @Override //birds have faster acceleration is determine on health
    public void accelerate() {
        if (getWings() == true) { //if wings are open
            setSpeed(getHealth() / 5 + getSpeed());
        } else if (getWings() == false) {
            setSpeed(2 + getSpeed() / 2);  //bird moves slower when not flying
        }
    }

    Adventure gameStatus = new Adventure();
    
    @Override
    public void move() { //each movement decrements health 
        setPosition(getPosition() + getSpeed() * getDirection());
        setHealth(getHealth() - (getSpeed() / 2));
        if (getHealth() <= 0)
        {
            gameStatus.setStatus(false);
            System.out.println("--------------------------GAME OVER!---------------------------------"
                    + "\nYour bird is dead, all values returned to default");
            setSpeed(0);
            setHealth(gameStatus.determineHealth());
            setPosition(0);
            setWings(false);
            setAltitude(0);
            
        }
    }

    //cannot fly without wings opened
    public void climb() {
        if (getWings() == true) {
            setAltitude(getAltitude() + 10); //increases the altitude of the bird by 10
        } else if (getWings() == false) {
            System.out.println("Please open your wings to fly");
        }
    }

    public void atNest() {

        if (getPosition() >= 100) { //if bird has reacher position 100 it can recover 100 health points
            setWings(false);
            setAltitude(0);
            setSpeed(0);
            if (getEyes() == true) { //user is prompted to open or close eyes
                setHealth(getHealth()+ 50);//adds 50 to health
                setPosition(getPosition() - 65); //lose 65 position
            } else if (getEyes() == false) {
                setPosition(getPosition() - 20); //if eyes are closed
                setHealth(getHealth() + 20); //only recover a little health
                setSpeed(0);
            }
        } else {
            System.out.println("Sorry, you have not reached position 100 or over yet, you cannot nest");
        }
    }

    public void breakOpen() { //get a random amount of health by braking open food
        setHealth(getHealth() + (int) (Math.random() * 50 + 1)); //gets a random amount of health between 1-50
        setHealth(getHealth() - 10); //loose default health
        setPosition(getPosition() - 10);//loose default position
    }

}
